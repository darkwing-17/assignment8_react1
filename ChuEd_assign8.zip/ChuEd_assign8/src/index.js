import React from 'react';
import ReactDOM from 'react-dom';
import './reset.css';
import './text.css';
import AssignApp8 from './AssignApp8';

ReactDOM.render(<AssignApp8 />, document.getElementById('root'));


